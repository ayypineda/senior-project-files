window.addEventListener('DOMContentLoaded', ()=> 
{
    const boxes = document.querySelectorAll('.tick');
    const green = document.getElementById('greenlight');
    const mainpage = document.getElementById('toolbox');

    function tickedOff()
    {
        const allTicked = Array.from(boxes).every(cb = cb.checked);
        green.style.display = allTicked ? 'inline-block' :'none';

    }

    boxes.forEach(cb => cb.addEventListener('change', tickedOff));

    green.addEventListener('click', () => 
    {
        document.getElementById('checklist').style.display = 'none';
        green.style.display = 'none';
        mainpage.style.display = 'block';
    });

});